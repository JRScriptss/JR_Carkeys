# JR_Carkeys

# DEPENDENCIES :

ox_lib

QB/ESX/QBOX Framework

OX/QB Inventory

Onesync Infinity

#Step 1: Drag and Drop
Install the items and images from `INSTALL`.

#Step 2: Start the script
Ensure the script in server.cfg

#Step 3: Restart the Server


# Client Exports
Remove Temporary Key
exports.JR_Carkeys:RemoveTempKeys(plate)
**plate: string Vehicle Plate Number

Get Permanent Key (Item)
exports.JR_Carkeys:GiveKeyItem(plate, vehicle)
**plate: string Vehicle Plate Number
**vehicle: number Vehicle Entity Id

Remove Permanent Key (Item)
exports.JR_Carkeys:RemoveKeyItem(plate)
**plate: string Vehicle Plate Number

Check Temporary Key
exports.JR_Carkeys:HaveTemporaryKey(plate)
**plate: string Vehicle Plate Number

Check Permanent Key (Item)
exports.JR_Carkeys:HavePermanentKey(plate)
**plate: string Vehicle Plate Number

# Server Exports
Remove Temporary Key
exports.JR_Carkeys:RemoveTempKeys(source, plate)
**source: number Player Source Id
**plate: string Vehicle Plate Number

Get Permanent Key (Item)
exports.JR_Carkeys:GiveKeyItem(src, plate, netId)
**source: number Player Source Id
**plate: string Vehicle Plate Number
**netId: number Vehicle Network Id

Remove Permanent Key (Item)
exports.JR_Carkeys:RemoveKeyItem(source, plate)
**source: number Player Source Id
**plate: string Vehicle Plate Number

Check Temporary Key
exports.JR_Carkeys:HaveTemporaryKey(source, plate)
**source: number Player Source Id
**plate: string Vehicle Plate Number

Check Permanent Key (Item)
exports.JR_Carkeys:HavePermanentKey(source, plate)
**source: number Player Source Id
**plate: string Vehicle Plate Number