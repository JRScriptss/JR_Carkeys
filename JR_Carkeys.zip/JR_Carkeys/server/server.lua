local Bridge = require 'server.bridge'

local VehicleList = {}
local getItemInfo = Shared.Inventory == 'qb' and function(item) return item.info end or function(item) return item.metadata end

local function RemoveSpecialCharacter(txt)
    return txt:gsub("%W", "")
end

function GiveTempKeys(id, plate)
    local citizenid = Bridge:GetPlayerCitizenId(id)
    if not VehicleList[citizenid] then VehicleList[citizenid] = {} end
    plate = RemoveSpecialCharacter(plate)
    table.insert(VehicleList[citizenid], plate)
    local ndata = {
        title = 'Recieved',
        description = 'You got temporary key to the vehicle',
        type = 'success'
    }
    TriggerClientEvent('ox_lib:notify', id, ndata)
    TriggerClientEvent('JR_Carkeys:client:addtempkeys', id, plate)
end

function RemoveTempKeys(id, plate)
    local citizenid = Bridge:GetPlayerCitizenId(id)
    plate = RemoveSpecialCharacter(plate)
    if VehicleList[citizenid] and VehicleList[citizenid][plate] then
        table.remove(VehicleList[citizenid], plate)
    end
    TriggerClientEvent('JR_Carkeys:client:removetempkeys', id, plate)
end

exports('GiveTempKeys', function(src, plate)
    if not plate then
        local nData = {
            title = 'Failed',
            description = 'No Vehicle Plate Found',
            type = 'error'
        }
        TriggerClientEvent('ox_lib:notify', src, nData)
        return
    end
    GiveTempKeys(src, plate)
end)

exports('RemoveTempKeys', function(src, plate)
    if not plate then
        local nData = {
            title = 'Failed',
            description = 'No Vehicle Plate Found',
            type = 'error'
        }
        TriggerClientEvent('ox_lib:notify', src, nData)
        return
    end
    RemoveTempKeys(src, plate)
end)

exports('GiveKeyItem', function(src, plate, netId)
    if not src or not GetPlayerName(src) then
        print("Error: Invalid player ID in GiveKeyItem. Received src:", src)
        return
    end

    if not plate or type(plate) ~= "string" or plate == "" then
        print("Error: Invalid or Missing Vehicle Plate in GiveKeyItem. Received plate:", plate)
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Failed',
            description = 'Invalid or Missing Vehicle Plate',
            type = 'error'
        })
        return
    end

    if not netId or type(netId) ~= "number" then
        print("Error: Invalid or Missing netId in GiveKeyItem. Received netId:", netId)
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Failed',
            description = 'Invalid or Missing Vehicle Entity',
            type = 'error'
        })
        return
    end

    local vehicle = NetworkGetEntityFromNetworkId(netId)
    if not vehicle or not DoesEntityExist(vehicle) then
        print("Error: Could not retrieve vehicle entity from netId. Received netId:", netId)
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Failed',
            description = 'Could not retrieve vehicle entity',
            type = 'error'
        })
        return
    end

    print("Success: Giving key for plate:", plate, "Vehicle netId:", netId)

    TriggerClientEvent('JR_Carkeys:client:setplayerkey', src, plate, netId)
end)

exports('RemoveKeyItem', function(src, plate)
    if not src or not GetPlayerName(src) then
        print("Error: Invalid player ID in RemoveKeyItem.")
        return
    end

    if not plate or type(plate) ~= "string" then
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Failed',
            description = 'Invalid or Missing Vehicle Plate',
            type = 'error'
        })
        return
    end

    TriggerClientEvent('JR_Carkeys:client:removeplayerkey', src, plate)
end)

exports('HaveTemporaryKey', function(src, plate)
    if not src or not GetPlayerName(src) then
        print("Error: Invalid player ID in HaveTemporaryKey.")
        return false
    end

    if not plate or type(plate) ~= "string" then
        print("Error: No valid vehicle plate provided in HaveTemporaryKey.")
        return false
    end

    return lib.callback.await('JR_Carkeys:client:havekey', src, 'temp', plate)
end)

exports('HavePermanentKey', function(src, plate)
    if not src or not GetPlayerName(src) then
        print("Error: Invalid player ID in HavePermanentKey.")
        return false
    end

    if not plate or type(plate) ~= "string" then
        print("Error: No valid vehicle plate provided in HavePermanentKey.")
        return false
    end

    return lib.callback.await('JR_Carkeys:client:havekey', src, 'perma', plate)
end)

lib.callback.register('JR_Carkeys:server:getvehiclekeys', function(source)
    local citizenid = Bridge:GetPlayerCitizenId(source)
    return VehicleList[citizenid] or {}
end)

RegisterNetEvent('JR_Carkeys:server:setVehLockState', function(vehNetId, state)
    SetVehicleDoorsLocked(NetworkGetEntityFromNetworkId(vehNetId), state)
end)

RegisterNetEvent('JR_Carkeys:server:acquiretempvehiclekeys', function(plate)
    local src = source
    GiveTempKeys(src, plate)
end)

RegisterNetEvent('JR_Carkeys:server:removetempvehiclekeys', function(plate)
    local src = source
    RemoveTempKeys(src, plate)
end)

RegisterNetEvent('JR_Carkeys:server:removelockpick', function(item)
    Bridge:RemoveItem(source, item)
end)

RegisterNetEvent('JR_Carkeys:server:acquirevehiclekeys', function(plate, model)
    local src = source
	local Player = Bridge:GetPlayer(src)
    if Player then
        local info = {}
		info.label = model.. '-' ..plate
        info.plate = plate
		Bridge:AddItem(src, 'vehiclekey', info)
	end
end)

RegisterNetEvent('JR_Carkeys:server:removevehiclekeys', function(plate)
    local src = source
    local keys = Bridge:GetPlayerItemsByName(src, 'vehiclekey')
    for _, v in pairs(keys) do
        local info = getItemInfo(v)
        if info.plate == plate then
            Bridge:RemoveItem(src, 'vehiclekey', v.slot)
            break
        end
    end
end)

RegisterNetEvent('JR_Carkeys:server:stackkeys', function()
    local src = source
    local bagFound = Bridge:GetPlayerItemByName(src, 'keybag')
    local keys = Bridge:GetPlayerItemsByName(src, 'vehiclekey')
    local plates = {}
    local platestxt = ''
    for _, v in pairs(keys) do
        local info = getItemInfo(v)
        if info.plate then
            plates[#plates+1] = {
                plate = info.plate,
                label = info.label
            }
            platestxt = platestxt..info.plate..', '
            Bridge:RemoveItem(src, 'vehiclekey', v.slot)
        end
    end
    if bagFound then
        local info = getItemInfo(bagFound)
        local getplates = info.plates
        for _, v in pairs(getplates) do
            plates[#plates+1] = {
                plate = v.plate,
                label = v.label
            }
            platestxt = platestxt..v.plate..', '
        end
        Bridge:RemoveItem(src, 'keybag', bagFound.slot)
    end
    Bridge:AddItem(src, 'keybag', {plates = plates, platestxt = platestxt})
end)

RegisterNetEvent('JR_Carkeys:server:unstackkeys', function()
    local src = source
    local bag = Bridge:GetPlayerItemByName(src, 'keybag')
    if not bag then
        local ndata = {
            description = 'You don\'t have a key bag',
            type = 'error'
        }
        TriggerClientEvent('ox_lib:notify', src, ndata)
        return
    end
    Bridge:RemoveItem(src, 'keybag', bag.slot)
    local itemInfo = getItemInfo(bag)
    for _, v in pairs(itemInfo.plates) do
        local info = {}
		info.label = v.label
        info.plate = v.plate
        Bridge:AddItem(src, 'vehiclekey', info)
    end
end)

lib.versionCheck('SOH69/JR_Carkeys')