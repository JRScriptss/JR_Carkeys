#ITEMS
["vehiclekey"] = {
	label = "Vehicle Keys",
	description = 'This is a car key, take good care of it, if you lose it you probably won\'t be able to use your car',
	weight = 10,
	stack = false
},
