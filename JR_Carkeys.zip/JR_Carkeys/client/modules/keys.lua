local VehicleKeys = require 'client.interface'
local InventoryBridge = require 'bridge.inventory.client'
local Utils = require 'client.modules.utils'

local KeyManagement = {
    getItemInfo = Shared.Inventory == 'qb' and function(item) return item.info end or function(item) return item.metadata end
}

function KeyManagement:SetVehicleKeys()
    VehicleKeys.playerKeys = {}
    local PlayerItems = InventoryBridge:GetPlayerItems()
    if not PlayerItems then return end
    for _, item in pairs(PlayerItems) do
        local itemInfo = self.getItemInfo(item)
        if itemInfo and item.name == "vehiclekey" then
            VehicleKeys.playerKeys[#VehicleKeys.playerKeys+1] = Utils:RemoveSpecialCharacter(itemInfo.plate)
        elseif itemInfo and item.name == "keybag" then
            for _,v in pairs(itemInfo.plates) do
                VehicleKeys.playerKeys[#VehicleKeys.playerKeys+1] = Utils:RemoveSpecialCharacter(v.plate)
            end
        end
    end
end

function KeyManagement:GetKeys()
    lib.callback('JR_Carkeys:server:getvehiclekeys', false, function(keysList)
        VehicleKeys.playerTempKeys = keysList
    end)
end

local lastLockAction = 0 -- Prevents duplicate notifications

function KeyManagement:ToggleVehicleLock(vehicle, remote)
    if not DoesEntityExist(vehicle) then return end -- Ensure vehicle exists

    -- Prevent double execution by adding a cooldown (500ms delay)
    local currentTime = GetGameTimer()
    if currentTime - lastLockAction < 500 then return end
    lastLockAction = currentTime

    -- Request animation dictionary and play animation for a longer duration
    local animDict = "anim@mp_player_intmenu@key_fob@"
    local animName = "fob_click"

    lib.requestAnimDict(animDict) -- Ensure animation dictionary is loaded
    TaskPlayAnim(cache.ped, animDict, animName, 3.0, 3.0, 2000, 49, 0, false, false, false) -- Animation now lasts 2 seconds

    -- Play lock/unlock sound
    TriggerServerEvent("InteractSound_SV:PlayWithinDistance", 5, "lock", 0.3)

    -- Ensure control over vehicle before modifying state
    NetworkRequestControlOfEntity(vehicle)

    local vehLockStatus = GetVehicleDoorLockStatus(vehicle)

    -- Prevent duplicate notifications
    Wait(250) -- Small delay before processing lock state

    if vehLockStatus == 1 then
        -- Locking vehicle
        TriggerServerEvent('JR_Carkeys:server:setVehLockState', NetworkGetNetworkIdFromEntity(vehicle), 4)
        SetVehicleDoorsLockedForAllPlayers(vehicle, true)

        -- Only one notification appears
        lib.notify({
            description = '🔒 Vehicle Locked',
            type = 'error'
        })
    else
        -- Unlocking vehicle
        TriggerServerEvent('JR_Carkeys:server:setVehLockState', NetworkGetNetworkIdFromEntity(vehicle), 1)
        SetVehicleDoorsLockedForAllPlayers(vehicle, false)

        -- Only one notification appears
        lib.notify({
            description = '🔓 Vehicle Unlocked',
            type = 'success'
        })
    end

    -- Flash vehicle lights after toggling lock state
    if remote or not Shared.toggleLightsOnlyRemote then
        SetVehicleLights(vehicle, 2)
        Wait(300)
        SetVehicleLights(vehicle, 1)
        Wait(300)
        SetVehicleLights(vehicle, 0)
        Wait(400)
    end

    -- Clear animation after a longer delay
    Wait(500) -- Ensures animation fully plays before clearing
    ClearPedTasks(cache.ped)
end

RegisterCommand('togglelocks', function()
    if VehicleKeys.currentVehicle == 0 then
        local vehicle = lib.getClosestVehicle(GetEntityCoords(cache.ped), 3.0, false)
        if not vehicle then return end
        local plate = GetVehicleNumberPlateText(vehicle)
        if lib.table.contains(VehicleKeys.playerKeys, Utils:RemoveSpecialCharacter(plate)) then
            KeyManagement:ToggleVehicleLock(vehicle)
        end
        return
    end
    if lib.table.contains(VehicleKeys.playerKeys, VehicleKeys.currentVehiclePlate) then
        KeyManagement:ToggleVehicleLock(VehicleKeys.currentVehicle)
    end
end, false)

RegisterKeyMapping('togglelocks', 'LOCK Vehicle', 'keyboard', 'L')

RegisterCommand('engine', function()
    if VehicleKeys.currentVehicle then
        local EngineOn = GetIsVehicleEngineRunning(VehicleKeys.currentVehicle)
        if EngineOn then
            SetVehicleEngineOn(VehicleKeys.currentVehicle, false, false, true)
            VehicleKeys.isEngineRunning = false
            return
        end
        if VehicleKeys.hasKey then
            SetVehicleEngineOn(VehicleKeys.currentVehicle, true, true, true)
            VehicleKeys.isEngineRunning = true
            return
        end
    end
end, false)

RegisterKeyMapping('engine', "Toggle Engine", 'keyboard', 'G')

lib.callback.register('JR_Carkeys:client:getplate', function()
    if VehicleKeys.currentVehicle == 0 then return false end
    return VehicleKeys.currentVehiclePlate
end)

lib.callback.register('JR_Carkeys:client:havekey', function(type, plate)
    if type == 'temp' then
        return lib.table.contains(VehicleKeys.playerTempKeys, Utils:RemoveSpecialCharacter(plate))
    elseif type == 'perma' then
        return lib.table.contains(VehicleKeys.playerKeys, Utils:RemoveSpecialCharacter(plate))
    end
end)

RegisterNetEvent('JR_Carkeys:client:addtempkeys', function(plate)
    plate = Utils:RemoveSpecialCharacter(plate)
    VehicleKeys.playerTempKeys[#VehicleKeys.playerTempKeys+1] = plate
    if VehicleKeys.currentVehicle and cache.vehicle then
        local vehicleplate = Utils:RemoveSpecialCharacter(GetVehicleNumberPlateText(cache.vehicle))
        if vehicleplate == plate then
            VehicleKeys:Init(plate)
            SetVehicleEngineOn(VehicleKeys.currentVehicle, true, false, true)
            VehicleKeys.isEngineRunning = true
        end
    end
end)

RegisterNetEvent('JR_Carkeys:client:removetempkeys', function(plate)
    VehicleKeys.playerTempKeys[plate] = nil
    if VehicleKeys.currentVehicle and cache.vehicle then
        local vehicleplate = GetVehicleNumberPlateText(cache.vehicle)
        if VehicleKeys.currentVehiclePlate == vehicleplate then
            VehicleKeys.hasKey = false
            SetVehicleEngineOn(VehicleKeys.currentVehicle, false, false, true)
            VehicleKeys.isEngineRunning = false
            if not VehicleKeys.showTextUi then
                lib.showTextUI('Hotwire Vehicle', {
                    position = "left-center",
                    icon = 'h',
                })
                VehicleKeys.showTextUi = true
            end
        end
    end
end)

RegisterNetEvent('JR_Carkeys:client:setplayerkey', function(plate, netId)
    if not plate or not netId then
        return lib.notify({
            description = 'No Vehicle Data Found',
            type = 'error'
        })
    end

    local vehicle = NetworkGetEntityFromNetworkId(netId) -- Convert netId to entity
    if not vehicle or not DoesEntityExist(vehicle) then
        return lib.notify({
            description = 'Invalid Vehicle Entity',
            type = 'error'
        })
    end

    local model = GetLabelText(GetDisplayNameFromVehicleModel(GetEntityModel(vehicle)))
    TriggerServerEvent('JR_Carkeys:server:acquirevehiclekeys', plate, model)
end)

RegisterNetEvent('JR_Carkeys:client:removeplayerkey', function(plate)
    if not plate or type(plate) ~= "string" then
        return lib.notify({
            description = 'No Valid Vehicle Plate Found',
            type = 'error'
        })
    end
    TriggerServerEvent('JR_Carkeys:server:removevehiclekeys', plate)
end)

RegisterNetEvent('JR_Carkeys:client:givekeyitem', function()
    if VehicleKeys.currentVehicle == 0 then
        return lib.notify({
            description = 'You are not inside any vehicle',
            type = 'error'
        })
    end
    local model = GetLabelText(GetDisplayNameFromVehicleModel(GetEntityModel(VehicleKeys.currentVehicle)))
    if lib.progressBar({
        label = 'Making Vehicle Keys...',
        duration = 5000,
        position = 'bottom',
        useWhileDead = false,
        canCancel = true,
        disable = {
            car = true,
            move = true,
            combat = true
        }
    }) then
        TriggerServerEvent('JR_Carkeys:server:acquirevehiclekeys', VehicleKeys.currentVehiclePlate, model)
    else
        lib.notify({
            description = 'Action cancelled',
            type = 'error'
        })
    end
end)

RegisterNetEvent('JR_Carkeys:client:removekeyitem', function()
    if VehicleKeys.currentVehicle == 0 then
        return lib.notify({
            description = 'You are not inside any vehicle',
            type = 'error'
        })
    end
    TriggerServerEvent('JR_Carkeys:server:removevehiclekeys', VehicleKeys.currentVehiclePlate)
end)

RegisterNetEvent('JR_Carkeys:client:stackkeys', function()
    if lib.progressBar({
        label = 'Stacking Keys...',
        duration = 5000,
        position = 'bottom',
        useWhileDead = false,
        canCancel = true,
        anim = {
            dict = 'anim@amb@business@weed@weed_inspecting_high_dry@',
            clip = 'weed_inspecting_high_base_inspector'
        },
        disable = {
            car = true,
            move = true,
            combat = true
        }
    }) then
        TriggerServerEvent('JR_Carkeys:server:stackkeys')
    else
        lib.notify({
            description = 'Action cancelled',
            type = 'error'
        })
    end
end)

RegisterNetEvent('JR_Carkeys:client:unstackkeys', function()
    if lib.progressBar({
        label = 'Unstacking Keys...',
        duration = 5000,
        position = 'bottom',
        useWhileDead = false,
        canCancel = true,
        anim = {
            dict = 'anim@amb@business@weed@weed_inspecting_high_dry@',
            clip = 'weed_inspecting_high_base_inspector'
        },
        disable = {
            car = true,
            move = true,
            combat = true
        }
    }) then
        TriggerServerEvent('JR_Carkeys:server:unstackkeys')
    else
        lib.notify({
            description = 'Action cancelled',
            type = 'error'
        })
    end
end)

return KeyManagement