local VehicleKeys = require 'client.interface'

local Hotwire = {
    isHotwiring = false
}

function Hotwire:HotwireHandler()
    if self.isHotwiring then return end
    self.isHotwiring = true
--    exports.tk_dispatch:addCall({
--        title = 'Vehicle Theft',
--        code = '10-38',
--        priority = 'Priority 3',
--        coords = GetEntityCoords(PlayerPedId()),
--        showLocation = true,
--        showGender = true,
--        playSound = true,
--        blip = {
--            color = 3,
--            sprite = 357,
--            scale = 1.0,
--        },
--        jobs = {'police'}
--    })
    local skillSuccess = lib.skillCheck(
        {'easy', 'easy', 'medium', 'medium'}, -- 4 sequential skill checks
        {'w', 'a', 's', 'd'} -- Player must press these keys correctly
    )

    if not skillSuccess then
        lib.notify({
            title = 'Failed',
            description = 'You fumbled the wires and failed to hotwire the vehicle!',
            type = 'error'
        })
        self.isHotwiring = false
        return
    end
    local hotwireTime = math.random(Shared.hotwire.minTime, Shared.hotwire.maxTime)
    local success = false
    SetVehicleAlarm(VehicleKeys.currentVehicle, true)
    SetVehicleAlarmTimeLeft(VehicleKeys.currentVehicle, hotwireTime)
    
    lib.hideTextUI()
    VehicleKeys.showTextUi = false

    if lib.progressBar({
        label = Shared.hotwire.label,
        duration = hotwireTime,
        position = 'bottom',
        allowCuffed = false,
        useWhileDead = false,
        canCancel = true,
        disable = {
            car = true,
            move = true,
            combat = true
        },
        anim = {
            dict = 'anim@amb@clubhouse@tutorial@bkr_tut_ig3@',
            clip = 'machinic_loop_mechandplayer'
        }
    }) then
        -- Stress Gain
        TriggerServerEvent('hud:server:GainStress', Shared.hotwire.stressIncrease)

        -- Success Chance Check
        if (math.random() <= Shared.hotwire.chance) then
            TriggerServerEvent('JR_Carkeys:server:acquiretempvehiclekeys', VehicleKeys.currentVehiclePlate)
            SetVehicleEngineOn(VehicleKeys.currentVehicle, true, false, true)
            VehicleKeys.isEngineRunning = true
            success = true
            self.isHotwiring = false
            return
        end

        -- Hotwiring Failed
        lib.notify({
            title = 'Failed',
            description = 'Aah it seems too hard!',
            type = 'error'
        })
    else
        -- Progress Bar Canceled
        lib.notify({
            title = 'Failed',
            description = 'Cancelled hotwiring!',
            type = 'error'
        })
    end

    -- If hotwiring failed, allow retry
    if VehicleKeys.currentVehicle and VehicleKeys.isInDrivingSeat and not success and not VehicleKeys.showTextUi then
        lib.showTextUI('Hotwire Vehicle', {
            position = "left-center",
            icon = 'h',
        })
        VehicleKeys.showTextUi = true
    end

    self.isHotwiring = false
end

function Hotwire:SetupHotwire()
    CreateThread(function()
        while VehicleKeys.currentVehicle ~= 0 and not VehicleKeys.hasKey do
            SetVehicleEngineOn(VehicleKeys.currentVehicle, false, false, true)
            VehicleKeys.isEngineRunning = false
            if IsControlJustPressed(0, 74) then
                self:HotwireHandler()
            end
            Wait(5)
        end
    end)
end

return Hotwire
