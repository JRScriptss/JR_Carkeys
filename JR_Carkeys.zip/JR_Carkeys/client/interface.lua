local VehicleKeys = {
    playerKeys = {},
    playerTempKeys = {},
    AlertSend = false,
    isInDrivingSeat = false,
    currentVehicle = 0,
    showTextUi = false,
    hasKey = false,
    currentVehiclePlate = false,
    currentWeapon = false,
    isEngineRunning = false,
}

return VehicleKeys